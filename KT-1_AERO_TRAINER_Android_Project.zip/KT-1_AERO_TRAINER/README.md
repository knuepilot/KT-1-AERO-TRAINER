# KT-1 AERO TRAINER

KT-1 곡예비행 3D 시뮬레이터를 Android WebView 앱으로 감싼 프로젝트입니다.

## 앱 정보
- 표시 이름: KT-1 AERO TRAINER
- 화면: 가로 방향 / 전체 화면
- 원본 HTML의 3D 기동·재생·카메라·Procedure UI 유지
- Three.js는 GitHub Actions 빌드 때 앱 assets에 내려받아 포함하므로 설치 후 3D 렌더링에 네트워크가 필요하지 않습니다.

## APK 만들기 (PC 없이 GitHub 웹사이트에서)
1. GitHub에서 새 저장소를 만들고 이 ZIP의 압축을 푼 **내용물 전체**를 저장소 최상위에 업로드합니다.
2. `Actions` 탭에서 `Build KT-1 AERO TRAINER APK` 워크플로를 선택합니다.
3. `Run workflow`를 누르고 완료될 때까지 기다립니다.
4. 완료된 실행 페이지 아래 `Artifacts`에서 `KT-1-AERO-TRAINER-APK`를 눌러 다운로드합니다.
5. ZIP 안의 `app-debug.apk`를 휴대폰에서 실행해 설치합니다.

저장소 업로드 후 main 브랜치에 반영해도 자동 빌드됩니다. 최초 설치 시 Android에서 출처를 알 수 없는 앱 설치 허용이 필요할 수 있습니다.

## 참고
이 앱은 업로드된 HTML의 시뮬레이션을 WebView에 표시합니다. 시뮬레이션의 속도·고도·G 표시는 원본 HTML에 명시된 단순 에너지 모델 값이며 실제 비행자료나 조종 절차의 대체물이 아닙니다.
